#!/bin/sh
TARGETDIR=~/Dropbox/dev/d3_dashboard

cp backup.sh $TARGETDIR/
cp *.cfg $TARGETDIR/
cp *.py $TARGETDIR/
cp *.js $TARGETDIR/
cp *.TXT $TARGETDIR/
cp -R templates $TARGETDIR/
cp -R test $TARGETDIR/
